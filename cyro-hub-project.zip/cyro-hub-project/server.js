import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import session from 'express-session';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import Database from 'better-sqlite3';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import os from 'node:os';
import { spawn } from 'node:child_process';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = Number(process.env.PORT || 3000);
const isProd = process.env.NODE_ENV === 'production';
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  if (isProd) throw new Error('SESSION_SECRET must be set to a random value of at least 32 characters in production.');
  console.warn('WARNING: set SESSION_SECRET in .env before deployment.');
}
const dataDir = path.resolve(__dirname, 'data');
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(process.env.DATABASE_FILE || path.join(dataDir, 'cyro.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS memberships (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, plan TEXT NOT NULL, expires_at TEXT NOT NULL, created_at TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id));
CREATE TABLE IF NOT EXISTS addons (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, addon TEXT NOT NULL, expires_at TEXT NOT NULL, created_at TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id));
CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY, order_id TEXT UNIQUE NOT NULL, user_id INTEGER NOT NULL, plan TEXT NOT NULL, amount INTEGER NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id));
CREATE TABLE IF NOT EXISTS reports (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, kind TEXT NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL, created_at TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id));
`);

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(express.json({ limit: '64kb' }));
app.use(session({
  name: 'cyro.sid', secret: process.env.SESSION_SECRET || 'development-only-change-me-please-123456',
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: isProd, maxAge: 7 * 24 * 60 * 60 * 1000 }
  // express-session's default MemoryStore is for local development only. Use a persistent session store in production.
}));
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false });
const apiLimiter = rateLimit({ windowMs: 60 * 1000, limit: 90, standardHeaders: true, legacyHeaders: false });
app.use('/api', apiLimiter);
const nowIso = () => new Date().toISOString();
const getUser = req => req.session?.userId ? db.prepare('SELECT id,email FROM users WHERE id=?').get(req.session.userId) : null;
const requireUser = (req,res,next) => { if (!getUser(req)) return res.status(401).json({ message: 'Masuk ke akun CYRO HUB dulu.' }); next(); };
const activeMembership = userId => db.prepare('SELECT plan,expires_at AS expiresAt FROM memberships WHERE user_id=? AND expires_at>? ORDER BY expires_at DESC LIMIT 1').get(userId, nowIso());
const planConfig = {
  'vvip-1y': { amount: Number(process.env.MIDTRANS_VVIP_PRICE_IDR || 25000), label: 'CYRO VVIP 1 Tahun' },
  'am-1y': { amount: Number(process.env.MIDTRANS_AM_PRICE_IDR || 15000), label: 'CYRO Motion Pack 1 Tahun' }
};

app.get('/api/health', (_req,res) => res.json({ ok:true, service:'CYRO HUB API', integrations: {
  spotify: Boolean(process.env.SPOTIFY_CLIENT_ID && process.env.SPOTIFY_CLIENT_SECRET),
  ai: Boolean(process.env.AI_API_KEY),
  midtrans: Boolean(process.env.MIDTRANS_SERVER_KEY),
  database: true
}}));
app.post('/api/auth/register', authLimiter, async (req,res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({message:'Format email tidak valid.'});
  if (password.length < 10 || password.length > 200) return res.status(400).json({message:'Password harus 10–200 karakter.'});
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare('INSERT INTO users(email,password_hash,created_at) VALUES(?,?,?)').run(email,hash,nowIso());
    req.session.userId = Number(result.lastInsertRowid);
    res.status(201).json({ok:true,email});
  } catch (e) { if (String(e.code).includes('SQLITE_CONSTRAINT')) return res.status(409).json({message:'Email sudah terdaftar.'}); res.status(500).json({message:'Gagal membuat akun.'}); }
});
app.post('/api/auth/login', authLimiter, async (req,res) => {
  const email = String(req.body?.email || '').trim().toLowerCase(), password = String(req.body?.password || '');
  const user = db.prepare('SELECT * FROM users WHERE email=?').get(email);
  if (!user || !(await bcrypt.compare(password,user.password_hash))) return res.status(401).json({message:'Email atau password salah.'});
  req.session.regenerate(err => { if (err) return res.status(500).json({message:'Gagal membuat sesi.'}); req.session.userId=user.id; res.json({ok:true,email:user.email}); });
});
app.post('/api/auth/logout', (req,res) => req.session.destroy(() => { res.clearCookie('cyro.sid'); res.json({ok:true}); }));
app.get('/api/me', (req,res) => {
  const user = getUser(req); if (!user) return res.json({active:false, plan:'Free', expiresAt:null, authenticated:false});
  const m = activeMembership(user.id);
  const addons = db.prepare('SELECT addon,expires_at AS expiresAt FROM addons WHERE user_id=? AND expires_at>?').all(user.id,nowIso());
  res.json({active:Boolean(m),plan:m?.plan || 'Free',expiresAt:m?.expiresAt || null,authenticated:true,email:user.email,addons});
});

let spotifyToken = null, spotifyExpires = 0;
async function getSpotifyToken() {
  if (spotifyToken && Date.now() < spotifyExpires - 30000) return spotifyToken;
  if (!process.env.SPOTIFY_CLIENT_ID || !process.env.SPOTIFY_CLIENT_SECRET) throw new Error('Spotify credentials belum diatur di .env.');
  const basic = Buffer.from(`${process.env.SPOTIFY_CLIENT_ID}:${process.env.SPOTIFY_CLIENT_SECRET}`).toString('base64');
  const r = await fetch('https://accounts.spotify.com/api/token',{method:'POST',headers:{Authorization:`Basic ${basic}`,'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'client_credentials'})});
  const d = await r.json(); if (!r.ok) throw new Error(d.error_description || 'Spotify OAuth gagal.');
  spotifyToken=d.access_token; spotifyExpires=Date.now()+Number(d.expires_in||3600)*1000; return spotifyToken;
}
// Web media downloader powered by yt-dlp installed on the server.
function isUnsafeDownloadHost(hostname) {
  const h = hostname.toLowerCase().replace(/^\[|\]$/g, '');
  return h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.local') ||
    h === '::1' || h === '0.0.0.0' || h.startsWith('127.') || h.startsWith('10.') ||
    h.startsWith('192.168.') || h.startsWith('169.254.') ||
    /^172\.(1[6-9]|2\d|3[01])\./.test(h) || h === 'metadata.google.internal';
}
app.get('/api/downloader/status', (_req,res) => {
  const bin = process.env.YTDLP_PATH || 'yt-dlp';
  const child = spawn(bin, ['--version'], { stdio: ['ignore','pipe','ignore'] });
  let version = '';
  child.stdout.on('data', chunk => { version += chunk.toString(); });
  child.on('error', () => res.json({ available:false, message:'yt-dlp belum terpasang di server.' }));
  child.on('close', code => { if (!res.headersSent) res.json({ available:code===0, version:version.trim(), ffmpeg:process.env.FFMPEG_PATH || 'ffmpeg' }); });
});
app.post('/api/downloader/download', async (req,res) => {
  const raw = String(req.body?.url || '').trim();
  const format = String(req.body?.format || 'video');
  const quality = String(req.body?.quality || '720');
  let parsed;
  try { parsed = new URL(raw); } catch { return res.status(400).json({message:'URL tidak valid.'}); }
  if (!['http:','https:'].includes(parsed.protocol) || isUnsafeDownloadHost(parsed.hostname))
    return res.status(400).json({message:'URL ini tidak diizinkan. Gunakan URL publik HTTP/HTTPS.'});
  if (!['video','audio','best'].includes(format)) return res.status(400).json({message:'Format keluaran tidak dikenal.'});
  if (!['480','720','1080','best'].includes(quality)) return res.status(400).json({message:'Pilihan kualitas tidak valid.'});
  const bin = process.env.YTDLP_PATH || 'yt-dlp';
  const dir = await fs.promises.mkdtemp(path.join(os.tmpdir(), 'cyro-dl-'));
  const output = path.join(dir, 'cyro-media.%(ext)s');
  const args = ['--no-warnings','--no-playlist','--restrict-filenames','--max-filesize',String(process.env.DOWNLOAD_MAX_FILESIZE || '500M'),'--output',output];
  if (format === 'audio') args.push('-f','bestaudio/best','-x','--audio-format','mp3','--audio-quality','0','--ffmpeg-location',process.env.FFMPEG_PATH || 'ffmpeg');
  else if (format === 'video') args.push('-f',quality==='best'?'bestvideo*+bestaudio/best':`bestvideo[height<=${quality}]+bestaudio/best[height<=${quality}]/best`,`--merge-output-format`,'mp4');
  else args.push('-f','bestvideo*+bestaudio/best','--merge-output-format','mp4');
  args.push(raw);
  let settled = false;
  const cleanup = () => fs.promises.rm(dir,{recursive:true,force:true}).catch(()=>{});
  const child = spawn(bin,args,{stdio:['ignore','ignore','pipe']});
  let stderr='';
  child.stderr.on('data',chunk=>{stderr=(stderr+chunk.toString()).slice(-5000)});
  const timer=setTimeout(()=>child.kill('SIGKILL'), 4*60*1000);
  child.on('error',async err=>{if(settled)return;settled=true;clearTimeout(timer);await cleanup();if(!res.headersSent)res.status(503).json({message:err.code==='ENOENT'?'yt-dlp belum terpasang. Ikuti README untuk memasang yt-dlp dan FFmpeg.':'Gagal menjalankan downloader.'});});
  child.on('close',async code=>{
    if(settled)return; settled=true; clearTimeout(timer);
    if(code!==0){await cleanup();if(!res.headersSent)res.status(422).json({message:/ffmpeg/i.test(stderr)?'FFmpeg belum tersedia atau format tidak didukung.':(/login|sign in|private|members-only|age-restricted/i.test(stderr)?'Konten ini memerlukan login/akses khusus dan tidak bisa diambil oleh downloader publik.':'Situs tidak didukung, URL tidak tersedia, atau unduhan ditolak. Coba URL publik lain.')});return;}
    try {
      const files=(await fs.promises.readdir(dir)).filter(f=>!f.endsWith('.part')&&!f.endsWith('.ytdl'));
      if(!files.length) throw new Error('File hasil tidak ditemukan');
      const file=path.join(dir,files[0]);
      res.download(file,files[0],async()=>{await cleanup()});
    } catch { await cleanup(); if(!res.headersSent)res.status(500).json({message:'Gagal menyiapkan file unduhan.'}); }
  });
});

app.get('/api/spotify/search', async (req,res) => {
  const q=String(req.query.q||'').trim().slice(0,120); if (!q) return res.status(400).json({message:'Parameter q wajib diisi.'});
  try { const token=await getSpotifyToken(); const r=await fetch(`https://api.spotify.com/v1/search?type=track&limit=10&q=${encodeURIComponent(q)}`,{headers:{Authorization:`Bearer ${token}`}}); const d=await r.json(); if(!r.ok) return res.status(r.status).json({message:d.error?.message||'Spotify search gagal.'}); res.json({tracks:d.tracks||{items:[]}}); }
  catch(e){res.status(503).json({message:e.message||'Spotify tidak tersedia.'});}
});

app.post('/api/ai/generate', requireUser, async (req,res) => {
  const user=getUser(req), prompt=String(req.body?.prompt||'').trim(), mode=String(req.body?.mode||'general').slice(0,60);
  if (!prompt) return res.status(400).json({message:'Prompt wajib diisi.'});
  if (prompt.length>12000) return res.status(413).json({message:'Prompt terlalu panjang.'});
  if (mode==='personal' && !activeMembership(user.id)) return res.status(403).json({message:'CYRO VVIP aktif diperlukan untuk AI Personal.'});
  if (!process.env.AI_API_KEY) return res.status(503).json({message:'AI_API_KEY belum diatur di .env.'});
  const base=(process.env.AI_BASE_URL||'https://api.openai.com/v1').replace(/\/$/,'');
  try {
    const r=await fetch(`${base}/chat/completions`,{method:'POST',headers:{Authorization:`Bearer ${process.env.AI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.AI_MODEL||'gpt-4o-mini',messages:[{role:'system',content:`You are CYRO HUB AI. Answer safely, clearly, and helpfully. Mode: ${mode}.`},{role:'user',content:prompt}],temperature:0.7})});
    const d=await r.json(); if(!r.ok) return res.status(r.status===401?503:502).json({message:d.error?.message||'Provider AI gagal memproses permintaan.'});
    res.json({text:d.choices?.[0]?.message?.content||'Model tidak mengembalikan teks.'});
  } catch { res.status(502).json({message:'Tidak bisa terhubung ke provider AI.'}); }
});

app.post('/api/checkout', requireUser, async (req,res) => {
  const user=getUser(req), plan=String(req.body?.plan||''), item=planConfig[plan];
  if(!item) return res.status(400).json({message:'Paket tidak dikenal.'});
  if(!process.env.MIDTRANS_SERVER_KEY) return res.status(503).json({message:'MIDTRANS_SERVER_KEY belum diatur. Checkout belum aktif.'});
  const orderId=`CYRO-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
  const sandbox=String(process.env.MIDTRANS_ENV||'sandbox').toLowerCase()!=='production';
  const base=sandbox?'https://app.sandbox.midtrans.com/snap/v1/transactions':'https://app.midtrans.com/snap/v1/transactions';
  try {
    const r=await fetch(base,{method:'POST',headers:{Authorization:'Basic '+Buffer.from(process.env.MIDTRANS_SERVER_KEY+':').toString('base64'),'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify({transaction_details:{order_id:orderId,gross_amount:item.amount},item_details:[{id:plan,price:item.amount,quantity:1,name:item.label}],customer_details:{email:user.email}})});
    const d=await r.json(); if(!r.ok||!d.redirect_url) return res.status(502).json({message:d.error_messages?.join(', ')||'Gagal membuat transaksi Midtrans.'});
    db.prepare('INSERT INTO orders(order_id,user_id,plan,amount,status,created_at) VALUES(?,?,?,?,?,?)').run(orderId,user.id,plan,item.amount,'pending',nowIso());
    res.json({url:d.redirect_url,orderId});
  } catch {res.status(502).json({message:'Tidak bisa menghubungi Midtrans.'});}
});
app.post('/api/payments/midtrans', (req,res) => {
  const {order_id,status_code,gross_amount,signature_key,transaction_status,fraud_status}=req.body||{};
  if(!process.env.MIDTRANS_SERVER_KEY) return res.status(503).send('Payment provider not configured');
  const expected=crypto.createHash('sha512').update(`${order_id}${status_code}${gross_amount}${process.env.MIDTRANS_SERVER_KEY}`).digest('hex');
  const received=Buffer.from(String(signature_key||'')); const expectedBuf=Buffer.from(expected); if(received.length!==expectedBuf.length || !crypto.timingSafeEqual(expectedBuf,received)) return res.status(401).send('Invalid signature');
  const order=db.prepare('SELECT * FROM orders WHERE order_id=?').get(String(order_id)); if(!order) return res.status(404).send('Unknown order');
  if(Number(gross_amount)!==Number(order.amount)) return res.status(400).send('Amount mismatch');
  const paid=transaction_status==='settlement'||(transaction_status==='capture'&&fraud_status==='accept');
  const alreadyPaid=order.status==='paid';
  db.prepare('UPDATE orders SET status=? WHERE order_id=?').run(paid?'paid':String(transaction_status||'unknown'),String(order_id));
  if(paid&&!alreadyPaid){const expires=new Date(Date.now()+365*24*60*60*1000).toISOString();if(order.plan==='vvip-1y')db.prepare('INSERT INTO memberships(user_id,plan,expires_at,created_at) VALUES(?,?,?,?)').run(order.user_id,'CYRO VVIP · 1 Tahun',expires,nowIso());if(order.plan==='am-1y')db.prepare('INSERT INTO addons(user_id,addon,expires_at,created_at) VALUES(?,?,?,?)').run(order.user_id,'CYRO Motion Pack',expires,nowIso());}
  res.status(200).send('OK');
});
app.post('/api/reports', requireUser, (req,res) => {
  const user=getUser(req),kind=String(req.body?.kind||'Feedback').slice(0,40),title=String(req.body?.title||'').trim().slice(0,160),body=String(req.body?.body||'').trim().slice(0,5000);
  if(!title||!body)return res.status(400).json({message:'Judul dan detail wajib diisi.'});
  db.prepare('INSERT INTO reports(user_id,kind,title,body,created_at) VALUES(?,?,?,?,?)').run(user.id,kind,title,body,nowIso());res.status(201).json({ok:true});
});

app.use(express.static(path.join(__dirname,'public'),{extensions:['html']}));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(port,()=>console.log(`CYRO HUB listening at http://localhost:${port}`));
